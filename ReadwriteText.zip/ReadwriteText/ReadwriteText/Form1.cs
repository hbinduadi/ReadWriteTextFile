﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadwriteText
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRd_Click(object sender, EventArgs e)
        {
            using (StreamReader Sr = new StreamReader(@"c:\CC6\SampleDataFile.txt")) 
            {
                string line = Sr.ReadLine();
                while (line != null)
                {
                    tbres.Text += line;
                    line = Sr.ReadLine();
                }
            }
        }

        private void btnWrt_Click(object sender, EventArgs e)
        {
            using (StreamWriter Sw = new StreamWriter(@"C:\CC6\SampleDataFile.txt", true))
            {
                Sw.WriteLine(System.DateTime.Now.ToString());
                Sw.Close();

            }

        }

        private void btnclr_Click(object sender, EventArgs e)
        {
            tbres.Text = String.Empty;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
