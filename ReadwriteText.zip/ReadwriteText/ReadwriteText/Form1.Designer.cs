﻿namespace ReadwriteText
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbres = new System.Windows.Forms.TextBox();
            this.btnRd = new System.Windows.Forms.Button();
            this.btnWrt = new System.Windows.Forms.Button();
            this.btnclr = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbres
            // 
            this.tbres.Location = new System.Drawing.Point(192, 202);
            this.tbres.Multiline = true;
            this.tbres.Name = "tbres";
            this.tbres.Size = new System.Drawing.Size(410, 190);
            this.tbres.TabIndex = 0;
            // 
            // btnRd
            // 
            this.btnRd.Location = new System.Drawing.Point(45, 56);
            this.btnRd.Name = "btnRd";
            this.btnRd.Size = new System.Drawing.Size(137, 45);
            this.btnRd.TabIndex = 1;
            this.btnRd.Text = "Read File";
            this.btnRd.UseVisualStyleBackColor = true;
            this.btnRd.Click += new System.EventHandler(this.btnRd_Click);
            // 
            // btnWrt
            // 
            this.btnWrt.Location = new System.Drawing.Point(219, 56);
            this.btnWrt.Name = "btnWrt";
            this.btnWrt.Size = new System.Drawing.Size(133, 45);
            this.btnWrt.TabIndex = 2;
            this.btnWrt.Text = "Write Date to File";
            this.btnWrt.UseVisualStyleBackColor = true;
            this.btnWrt.Click += new System.EventHandler(this.btnWrt_Click);
            // 
            // btnclr
            // 
            this.btnclr.Location = new System.Drawing.Point(397, 56);
            this.btnclr.Name = "btnclr";
            this.btnclr.Size = new System.Drawing.Size(118, 46);
            this.btnclr.TabIndex = 3;
            this.btnclr.Text = "Clear";
            this.btnclr.UseVisualStyleBackColor = true;
            this.btnclr.Click += new System.EventHandler(this.btnclr_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(559, 57);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(107, 45);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnclr);
            this.Controls.Add(this.btnWrt);
            this.Controls.Add(this.btnRd);
            this.Controls.Add(this.tbres);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbres;
        private System.Windows.Forms.Button btnRd;
        private System.Windows.Forms.Button btnWrt;
        private System.Windows.Forms.Button btnclr;
        private System.Windows.Forms.Button btnExit;
    }
}

